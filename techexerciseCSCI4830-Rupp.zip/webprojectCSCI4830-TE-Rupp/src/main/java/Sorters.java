import java.util.Comparator;
import javax.servlet.annotation.WebServlet;


/**
 * Servlet implementation class DaysSorter
 */
@WebServlet("/DaysSorter")
class DayOfWeekComparator implements Comparator<String> {
    private final String[] daysOfWeek = {"Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"};
    
    @Override
    public int compare(String day1, String day2) {
        int index1 = getIndex(day1);
        int index2 = getIndex(day2);
        return Integer.compare(index1, index2);
    }

    private int getIndex(String day) {
        for (int i = 0; i < daysOfWeek.length; i++) {
            if (daysOfWeek[i].equalsIgnoreCase(day)) {
                return i;
            }
        }
        // If day is not found, return a value greater than the maximum index
        return daysOfWeek.length;
    }
}

class SleepQualityComparator implements Comparator<Integer> {
    @Override
    public int compare(Integer sleep1, Integer sleep2) {
        return Integer.compare(sleep1, sleep2);
    }
}

class WinLossStats {
    private int wins;
    private int losses;

    public WinLossStats() {
        this.wins = 0;
        this.losses = 0;
    }

    public void incrementWins() {
        this.wins++;
    }

    public void incrementLosses() {
        this.losses++;
    }

    public int getWins() {
        return wins;
    }

    public int getLosses() {
        return losses;
    }
}