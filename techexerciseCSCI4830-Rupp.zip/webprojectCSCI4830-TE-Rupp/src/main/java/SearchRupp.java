import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Map;
import java.util.TreeMap;


import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/SearchRupp")
public class SearchRupp extends HttpServlet {
   private static final long serialVersionUID = 1L;

   public SearchRupp() {
      super();
   }

   protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      String keyword = request.getParameter("keyword");
      search(keyword, response);
   }

   void search(String keyword, HttpServletResponse response) throws IOException {
      response.setContentType("text/html");
      PrintWriter out = response.getWriter();
      String title = "Your Stats";
      String docType = "<!doctype html public \"-//w3c//dtd html 4.0 " + //
            "transitional//en\">\n"; //
      out.println(docType + //
            "<html>\n" + //
            "<head><title>" + title + "</title></head>\n" + //
            "<body bgcolor=\"#f0f0f0\">\n" + //
            "<h1 align=\"center\">" + title + "</h1>\n");

      Connection connection = null;
      PreparedStatement preparedStatement = null;
      try {
         DBConnectionRupp.getDBConnection();
         connection = DBConnectionRupp.connection;
         Map<String, int[]> dayStats = new TreeMap<>(new DayOfWeekComparator());
         Map<Integer, int[]> sleepWinRates = new TreeMap<>();

         String selectSQL = "SELECT * FROM UserData";
         preparedStatement = connection.prepareStatement(selectSQL);

         ResultSet rs = preparedStatement.executeQuery();
         
         int totalWins = 0;
         int totalLosses = 0;
         
         

         while (rs.next()) {
             String winLoss = rs.getString("winLoss");
             String day = rs.getString("day");
             int sleepQuality = rs.getInt("sleepquality");

             int wins = 0;
             int losses = 0;
             
             
             if (winLoss.equals("Win")) {
                 wins++;
             } else if (winLoss.equals("Loss")) {
                 losses++;
             } else {
                 System.err.println("Unexpected value in winLoss column: " + winLoss);
             }

             totalWins += wins;
             totalLosses += losses;
             
             
             
             int[] stats = dayStats.getOrDefault(day, new int[2]);
             stats[0] += wins; // Increment wins
             stats[1] += losses; // Increment losses
             dayStats.put(day, stats);
             
             int[] sleepStats = sleepWinRates.getOrDefault(sleepQuality, new int[2]);
             sleepStats[0] += wins; // Increment wins
             sleepStats[1] += losses; // Increment losses
             sleepWinRates.put(sleepQuality, sleepStats);
         }
         
         double overallWinRate = totalWins / (double) (totalWins + totalLosses);
         String overallFormattedWinRate = String.format("%.2f", overallWinRate * 100);
         
         out.println("Overall Win Rate: " + overallFormattedWinRate + "%<br>");
         out.println("" + "<br>");
         out.println("Day Winrates" + "<br>");
         System.out.println("Overall Win Rate: " + overallWinRate);
         
         for (Map.Entry<String, int[]> entry : dayStats.entrySet()) {
             String day = entry.getKey();
             int[] stats = entry.getValue();
             int wins = stats[0];
             int losses = stats[1];
             double winRate = wins / (double) (wins + losses);
             String formattedWinRate = String.format("%.2f", winRate * 100);
             out.println(day + ": " + formattedWinRate + "%<br>");
             System.out.println(day + ": Win Rate: " + winRate);
             
         }
         out.println("" + "<br>");
         for (Map.Entry<Integer, int[]> entry : sleepWinRates.entrySet()) {
        	    int sleepQuality = entry.getKey();
        	    int[] stats = entry.getValue();
        	    int wins = stats[0];
        	    int losses = stats[1];
        	    
        	    double winRate = wins / (wins + losses); // Calculate win rate for sleep quality
        	    String formattedWinRate = String.format("%.2f", winRate * 100);
        	    out.println("Sleep Quality: " + sleepQuality + "&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp Win Rate: " + formattedWinRate + "%<br>");
        	    System.out.println("Sleep Quality: " + sleepQuality + ",Win Rate: " + formattedWinRate);
        	}
         out.println("<a href=/webprojectCSCI4830-TE-Rupp/search_Rupp.html>Search Data</a> <br>");
         out.println("</body></html>");
         
         
         rs.close();
         preparedStatement.close();
         connection.close();
      } catch (SQLException se) {
         se.printStackTrace();
      } catch (Exception e) {
         e.printStackTrace();
      } finally {
         try {
            if (preparedStatement != null)
               preparedStatement.close();
         } catch (SQLException se2) {
         }
         try {
            if (connection != null)
               connection.close();
         } catch (SQLException se) {
            se.printStackTrace();
         }
      }
   }

   protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      doGet(request, response);
   }

}
